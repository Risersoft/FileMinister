/*
Run this script on:

        DES1-PC\SQLEXPRESS.scriptdb.pbomdb.new    -  This database will be modified

to synchronize it with:

        DES1-PC\SQLEXPRESS.pbomdb

You are recommended to back up your database before running this script

Script created by SQL Compare version 8.1.0 from Red Gate Software Ltd at 13/Jun/2013 14:40:23

*/
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[StdDrg]'
GO
CREATE TABLE [dbo].[StdDrg]
(
[StdDrgID] [int] NOT NULL IDENTITY(1, 1),
[CompleteNum] AS (((([stdseries]+' ')+[groupnum])+' ')+[drgnum]),
[DrgName] [varchar] (1000) NULL,
[Descrip] [varchar] (1000) NULL,
[RevDueFrom] [datetime] NULL,
[RevDue] [varchar] (1000) NULL,
[ForFile] [varchar] (1000) NULL,
[DesEmpID] [int] NULL,
[StdSeries] [varchar] (2) NULL,
[GroupNum] [varchar] (50) NULL,
[DrgNum] [varchar] (50) NULL,
[BOMMaxNum] [int] NULL,
[IsGhost] [bit] NULL,
[RevNum] [int] NULL,
[RevDate] [datetime] NULL,
[PDFSource] [varchar] (1000) NULL,
[HasCollec] [bit] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__StdDrg__E924BA5A0DAF0CB0] on [dbo].[StdDrg]'
GO
ALTER TABLE [dbo].[StdDrg] ADD CONSTRAINT [PK__StdDrg__E924BA5A0DAF0CB0] PRIMARY KEY CLUSTERED  ([StdDrgID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ProDocu]'
GO
CREATE TABLE [dbo].[ProDocu]
(
[ProDocuID] [int] NOT NULL IDENTITY(1, 1),
[DesDocID] [int] NULL,
[PIDUnitID] [int] NULL,
[DocName] [varchar] (1000) NULL,
[Suffix] [varchar] (1000) NULL,
[PreFix] [varchar] (1000) NULL,
[NumSheets] [varchar] (1000) NULL,
[NumCopies] [varchar] (1000) NULL,
[SerialNum] [decimal] (18, 4) NULL,
[DrgNum] [varchar] (1000) NULL,
[RevNum] [varchar] (1000) NULL,
[RevDate] [datetime] NULL,
[RefDrg] [varchar] (1000) NULL,
[Remark] [varchar] (1000) NULL,
[IssuedOn] [datetime] NULL,
[DrgOn] [datetime] NULL,
[ChkOn] [datetime] NULL,
[AppOn] [datetime] NULL,
[PlanOn] [datetime] NULL,
[BlankLineA] [bit] NULL,
[BlankLineB] [bit] NULL,
[HasBOM] [bit] NULL,
[HasCollec] [bit] NULL,
[BOMMaxNum] [int] NULL,
[ReportStatus] [varchar] (1000) NULL,
[ReportRemark] [varchar] (1000) NULL,
[DocEmpID] [int] NULL,
[PrepByID] [int] NULL,
[PrepByID2] [int] NULL,
[ChkByID] [int] NULL,
[AppByID] [int] NULL,
[PDFSource] [varchar] (1000) NULL,
[DesDocGrp] [varchar] (1000) NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__ProDocu__4904971120C1E124] on [dbo].[ProDocu]'
GO
ALTER TABLE [dbo].[ProDocu] ADD CONSTRAINT [PK__ProDocu__4904971120C1E124] PRIMARY KEY CLUSTERED  ([ProDocuID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemSubCats]'
GO
CREATE TABLE [dbo].[ItemSubCats]
(
[SubCatName] [nvarchar] (255) NULL,
[SubCatID] [int] NOT NULL IDENTITY(1, 1),
[InitialCode] [nvarchar] (50) NULL,
[ItemSchedID] [int] NULL,
[InvCATID] [int] NULL,
[ItemUnitID] [int] NULL,
[KeepTrack] [bit] NULL,
[RMCONMNTCAP] [int] NULL,
[VendorListHead] [varchar] (1000) NULL,
[strMaint] AS (case isnull([rmconmntcap],(0)) when (1) then 'R.M.' when (2) then 'Consumable' when (3) then 'Maint' when (4) then 'Capital Good' else 'N.D.' end),
[xName] [nvarchar] (100) NULL,
[yName] [nvarchar] (100) NULL,
[zName] [nvarchar] (100) NULL,
[sName] [nvarchar] (100) NULL,
[HasDefs] [bit] NULL,
[tempunitid] [int] NULL,
[pName] [varchar] (100) NULL,
[OldSCName] [varchar] (1000) NULL,
[Example] [varchar] (8000) NULL,
[CodePic] [image] NULL,
[NumGroups] [int] NULL,
[xNameCost] [varchar] (50) NULL,
[yNameCost] [varchar] (50) NULL,
[zNameCost] [varchar] (50) NULL,
[sNameCost] [varchar] (50) NULL,
[pNameCost] [varchar] (50) NULL,
[HasDefsCost] [bit] NULL,
[Remark] [varchar] (1000) NULL,
[ShortName] [varchar] (1000) NULL,
[IsWOSpecific] [bit] NULL,
[IsMacMaint] [bit] NULL,
[IsStock] [bit] NULL,
[ClassABC] [varchar] (1) NULL,
[ClassSDE] [varchar] (1) NULL,
[SelectVMSType] [int] NULL,
[CostingType] [int] NULL,
[CostingItemID] [int] NULL,
[AutoChkItemCode] [bit] NULL,
[ItemnameTemplate] [varchar] (1000) NULL,
[InTankDrawings] [bit] NULL,
[DrgBOMName] [varchar] (1000) NULL,
[BomSectionTypeCode] [int] NULL,
[Density] [decimal] (18, 4) NULL,
[CNCTypeID] [int] NULL,
[pValueA] [int] NULL,
[pValueB] [int] NULL,
[pValueC] [int] NULL,
[pValueD] [int] NULL,
[pValueE] [int] NULL,
[perWastage] [decimal] (18, 2) NULL,
[Dim1Param] [varchar] (50) NULL,
[Dim2Param] [varchar] (50) NULL,
[Dim3Param] [varchar] (50) NULL,
[ParamXMLx] [varchar] (8000) NULL,
[ParamXMLy] [varchar] (8000) NULL,
[ParamXMLz] [varchar] (8000) NULL,
[ParamXMLp] [varchar] (8000) NULL,
[ParamXMLs] [varchar] (8000) NULL,
[CostingPriceFac] [decimal] (18, 4) NULL,
[CodeFormula] [varchar] (1000) NULL,
[NameFormula] [varchar] (1000) NULL,
[vxName] [varchar] (50) NULL,
[vyName] [varchar] (50) NULL,
[MatHeadRemark] [varchar] (1000) NULL,
[CostingItemFormula] [varchar] (1000) NULL,
[CostSummParamIndex] [int] NULL,
[PurchaseSpec] [varchar] (1000) NULL,
[AdvanceMat] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__ItemSubC__396379752BFE89A6] on [dbo].[ItemSubCats]'
GO
ALTER TABLE [dbo].[ItemSubCats] ADD CONSTRAINT [PK__ItemSubC__396379752BFE89A6] PRIMARY KEY CLUSTERED  ([SubCatID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemScheds]'
GO
CREATE TABLE [dbo].[ItemScheds]
(
[ItemSchedID] [int] NOT NULL,
[SchedCode] [varchar] (2) NULL,
[SchedName] [nvarchar] (255) NULL,
[pNameA] [varchar] (100) NULL,
[pXMLA] [varchar] (8000) NULL,
[pNameB] [varchar] (100) NULL,
[pXMLB] [varchar] (8000) NULL,
[pNameC] [varchar] (100) NULL,
[pXMLC] [varchar] (8000) NULL,
[pNameD] [varchar] (100) NULL,
[pXMLD] [varchar] (8000) NULL,
[pNameE] [varchar] (100) NULL,
[pXMLE] [varchar] (8000) NULL,
[HasParams] [bit] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__ItemSche__1E4D7A3A1CBC4616] on [dbo].[ItemScheds]'
GO
ALTER TABLE [dbo].[ItemScheds] ADD CONSTRAINT [PK__ItemSche__1E4D7A3A1CBC4616] PRIMARY KEY CLUSTERED  ([ItemSchedID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Items]'
GO
CREATE TABLE [dbo].[Items]
(
[ItemID] [int] NOT NULL IDENTITY(1, 1),
[ItemCode] [nvarchar] (50) NULL,
[SubCatID] [int] NULL,
[ItemSizeID] [int] NULL,
[ItemName] [nvarchar] (255) NULL,
[IsCritical] [bit] NULL,
[ShelfLife] [int] NULL,
[MinLevel] [real] NULL,
[WarnLevel] [real] NULL,
[NextIndex] [int] NULL,
[xValue] [decimal] (18, 4) NULL,
[yValue] [decimal] (18, 4) NULL,
[zValue] [decimal] (18, 4) NULL,
[pValue] [decimal] (18, 4) NULL,
[sValue] [varchar] (50) NULL,
[ParamLayoutCols] [smallint] NULL,
[ShortName] [varchar] (50) NULL,
[AcceptWO] [bit] NULL,
[MatSpec] [varchar] (1000) NULL,
[QtyDef] [int] NULL,
[QtyAsReq] [bit] NULL,
[MatListOK] [bit] NULL,
[OldCode] [varchar] (50) NULL,
[OldName] [varchar] (1000) NULL,
[CostingItemID] [int] NULL,
[MinOrderQty] [decimal] (18, 4) NULL,
[Application] [varchar] (1000) NULL,
[BOMThk] [decimal] (18, 4) NULL,
[BOMMatSection] [varchar] (1000) NULL,
[WtPerMtr] [decimal] (18, 4) NULL,
[AreaPerMtr] [decimal] (18, 4) NULL,
[WtPerNo] [decimal] (18, 4) NULL,
[SectionDim1] [decimal] (18, 4) NULL,
[SectionDim2] [decimal] (18, 4) NULL,
[SectionDim3] [decimal] (18, 4) NULL,
[PurchasePrice] [decimal] (18, 4) NULL,
[PurchPriceLastUpd] [datetime] NULL,
[CostingPrice] [decimal] (18, 4) NULL,
[SelectVMSType] [int] NULL,
[CreatedBy] [varchar] (50) NULL,
[CreatedOn] [datetime] NULL,
[LastModBy] [varchar] (50) NULL,
[LastModOn] [datetime] NULL,
[LastModApp] [varchar] (50) NULL,
[BOMNonStd] [bit] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__Items__727E83EB2FCF1A8A] on [dbo].[Items]'
GO
ALTER TABLE [dbo].[Items] ADD CONSTRAINT [PK__Items__727E83EB2FCF1A8A] PRIMARY KEY CLUSTERED  ([ItemID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncStringNum]'
GO











CREATE  function [dbo].[fncStringNum](@itemnum varchar(1000), @maxnumber int)
returns varchar(1000)
begin
	declare @tempname varchar(1000)
	
set @tempname=
	case when @maxnumber>99 then
		case when len(@itemnum)=1 then '00'
		when len(@itemnum)=2 then '0'
		else '' end 
	when @maxnumber>9 then
		case when len(@itemnum)=1 then '0'
		else '' end 
	else  '' end +@itemnum 


	return @tempname
end















GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItems]'
GO
CREATE TABLE [dbo].[DrgItems]
(
[DrgItemID] [int] NOT NULL IDENTITY(1, 1),
[StdDrgID] [int] NULL,
[ProDocuID] [int] NULL,
[ItemID] [int] NULL,
[IsCollection] [bit] NULL,
[IsBoughtOut] [bit] NULL,
[IsDeleted] [bit] NULL,
[ItemCollecTypeCode] [int] NULL,
[RefDrgItemID] [int] NULL,
[ItemNum1] [int] NULL,
[ItemNum2] [varchar] (50) NULL,
[ItemNum] [varchar] (50) NULL,
[Description] [varchar] (1000) NULL,
[DescripChart] [varchar] (1000) NULL,
[DescripChartAddl] [varchar] (1000) NULL,
[MatSection] [varchar] (1000) NULL,
[Thk] [decimal] (18, 2) NULL,
[Length] [varchar] (50) NULL,
[Width] [varchar] (50) NULL,
[Length2] [varchar] (50) NULL,
[Width2] [varchar] (50) NULL,
[InnerDia] [varchar] (50) NULL,
[OuterDia] [varchar] (50) NULL,
[Material] [varchar] (1000) NULL,
[Specification] [varchar] (1000) NULL,
[AddlSpec] [varchar] (1000) NULL,
[Qty] [decimal] (18, 2) NULL,
[Remark] [varchar] (1000) NULL,
[Weight] [decimal] (18, 4) NULL,
[CNCDrg] [varchar] (1000) NULL,
[Category] [varchar] (1000) NULL,
[SubCategory] [varchar] (1000) NULL,
[RectReduceXML] [varchar] (8000) NULL,
[RoundReduceXML] [varchar] (8000) NULL,
[TriangleReduceXML] [varchar] (8000) NULL,
[RadiusReduceXML] [varchar] (8000) NULL,
[TotalArea] [decimal] (18, 4) NULL,
[SeeDetail] [bit] NULL,
[IsManualWt] [bit] NULL,
[GasketTypeCode] [int] NULL,
[ThkParamID] [int] NULL,
[LengthParamID] [int] NULL,
[WidthParamID] [int] NULL,
[Length2ParamID] [int] NULL,
[Width2ParamID] [int] NULL,
[InnerDiaParamID] [int] NULL,
[OuterDiaParamID] [int] NULL,
[ThreadParamID] [int] NULL,
[ParamReqXML] [varchar] (8000) NULL,
[ParamValueXML] [varchar] (8000) NULL,
[HasNoJoints] [bit] NULL,
[HasLegend] [bit] NULL,
[CNCDrg2] [varchar] (1000) NULL,
[CNCDrg3] [varchar] (1000) NULL,
[CNCDrg4] [varchar] (1000) NULL,
[NoCommonCut] [bit] NULL,
[IsWelded] [bit] NULL,
[ShowNonStd] [bit] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DrgItems__F80CE9EB24927208] on [dbo].[DrgItems]'
GO
ALTER TABLE [dbo].[DrgItems] ADD CONSTRAINT [PK__DrgItems__F80CE9EB24927208] PRIMARY KEY CLUSTERED  ([DrgItemID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItems] on [dbo].[DrgItems]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DrgItems] ON [dbo].[DrgItems] ([ProDocuID], [StdDrgID], [ItemNum]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CNCTypes]'
GO
CREATE TABLE [dbo].[CNCTypes]
(
[CNCTypeID] [int] NOT NULL IDENTITY(1, 1),
[CNCTypeName] [varchar] (1000) NULL,
[IsGasket] [bit] NULL,
[InItemCollec] [bit] NULL,
[IsHardware] [bit] NULL,
[TitleQC] [varchar] (8000) NULL,
[WeldedTypeID] [int] NULL,
[BOMSepCharts] AS (case when isnull([isgasket],(0))=(1) OR isnull([ishardware],(0))=(1) then (1) else (0) end),
[InAttachMatList] [bit] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CNCTypeCode] on [dbo].[CNCTypes]'
GO
ALTER TABLE [dbo].[CNCTypes] ADD CONSTRAINT [PK_CNCTypeCode] PRIMARY KEY CLUSTERED  ([CNCTypeID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemUnits]'
GO
CREATE TABLE [dbo].[ItemUnits]
(
[ItemUnitID] [int] NOT NULL IDENTITY(1, 1),
[NameSingular] [varchar] (50) NOT NULL,
[NamePlural] [varchar] (50) NULL,
[UnitName] AS ([nameplural])
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__ItemUnit__2C260C293587F3E0] on [dbo].[ItemUnits]'
GO
ALTER TABLE [dbo].[ItemUnits] ADD CONSTRAINT [PK__ItemUnit__2C260C293587F3E0] PRIMARY KEY CLUSTERED  ([ItemUnitID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListItems]'
GO

















CREATE    function [dbo].[desListItems]()
returns table
return (


select items.itemid,

case when items.itemid is null then 'No items in this sub cat' else items.itemname end as ItemName,


ItemUnits.NameSingular,items.bomnonstd,
itemunits.itemunitid,itemunits.nameplural as unitname,items.acceptwo,

items.shortname,items.paramlayoutcols,items.itemsizeid,
ItemUnits.NamePlural,Items.ItemCode,ItemSubcats.subcatid,


itemsubcats.intankdrawings, cnctypes.isgasket, cnctypes.ishardware, cnctypes.initemcollec,cnctypes.weldedtypeid,
case when isnull(itemsubcats.drgbomname,'')='' then subcatname else drgbomname end as drgbomname,
cnctypes.bomsepcharts,
itemsubcats.bomsectiontypecode, cnctypes.cnctypeid,cnctypes.cnctypename,
items.bomthk,
items.bommatsection,
itemsubcats.density,
items.wtpermtr,
items.areapermtr,
items.wtperno,
itemsubcats.dim1param, itemsubcats.dim2param, itemsubcats.dim3param,
items.sectiondim1, items.sectiondim2, items.sectiondim3,
itemsubcats.pvaluea, itemsubcats.pvalueb, itemsubcats.pvaluec, itemsubcats.pvalued, itemsubcats.pvaluee,

itemsubcats.hasdefs, xvalue,yvalue,zvalue,svalue,pvalue, 
items.minlevel,items.warnlevel,items.shelflife, 

itemsubcats.initialcode,itemsubcats.subcatname,itemscheds.itemschedid,itemscheds.schedname,

itemsubcats.xname,itemsubcats.yname,itemsubcats.zname,itemsubcats.sname,itemsubcats.pname,
itemsubcats.paramxmlx, itemsubcats.paramxmly, itemsubcats.paramxmlz, itemsubcats.paramxmlp, itemsubcats.paramxmls, 

items.matspec,items.qtydef,items.qtyasreq,items.matlistOK



from itemsubcats
	left join items on items.subcatid = itemsubcats.subcatid
	inner join itemunits on itemsubcats.itemunitid = itemunits.itemunitid
	inner join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
	left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid








)
















































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItemBOM]'
GO
CREATE TABLE [dbo].[DrgItemBOM]
(
[DrgItemBOMID] [int] NOT NULL IDENTITY(1, 1),
[DrgItemID] [int] NULL,
[ChildDrgItemID] [int] NULL,
[ItemID] [int] NULL,
[Qty] [decimal] (18, 2) NULL,
[Legend] [varchar] (50) NULL,
[Reference] [varchar] (1000) NULL,
[CNCDrg] [varchar] (1000) NULL,
[QtyParamID] [int] NULL,
[DescripBOM] [varchar] (1000) NULL,
[SpecBOM] [varchar] (1000) NULL,
[Weight] [decimal] (18, 4) NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DrgItemB__2F6BB98E286302EC] on [dbo].[DrgItemBOM]'
GO
ALTER TABLE [dbo].[DrgItemBOM] ADD CONSTRAINT [PK__DrgItemB__2F6BB98E286302EC] PRIMARY KEY CLUSTERED  ([DrgItemBOMID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[invListItems]'
GO










CREATE                    function [dbo].[invListItems]()
returns table
return (


select items.itemid,items.itemname,ItemUnits.NameSingular,
itemunits.itemunitid,itemunits.nameplural as unitname,items.acceptwo,
items.itemcode + '-' + items.itemname as iteminfo,
items.minorderqty, itemsubcats.classabc, items.[application],
items.purchaseprice,items.purchpricelastupd,itemscheds.schedcode,
isnull(itemsubcats.costingtype,0) as costingtype, itemscheds.pxmlc,
itemsubcats.perwastage,itemsubcats.drgbomname,

cnctypes.isgasket, cnctypes.initemcollec, cnctypes.ishardware, cnctypes.titleqc,
case when itemsubcats.costingtype=1 then items.costingitemid 
	when itemsubcats.costingtype=2 then itemsubcats.costingitemid
else null end as costingitemid,

itemsubcats.oldscname,items.oldcode,items.oldname,
isnull(itemsubcats.isstock,0) as  isstock,
items.shortname,items.paramlayoutcols,items.itemsizeid,
ItemUnits.NamePlural,Items.ItemCode,ItemSubcats.subcatid,
itemsubcats.invcatid,items.matspec,items.matlistok,items.qtyasreq,items.qtydef,

itemsubcats.hasdefs, xvalue,yvalue,zvalue,svalue,pValue, itemsubcats.keeptrack,
itemsubcats.pvaluea,itemsubcats.pvalueb,itemsubcats.pvaluec,itemsubcats.pvalued,itemsubcats.pvaluee,
cnctypes.cnctypeid, cnctypes.cnctypename, cnctypes.weldedtypeid,itemsubcats.bomsectiontypecode,
items.minlevel,items.warnlevel,items.shelflife,
items.wtperno,
items.bomthk,
items.bommatsection,
itemsubcats.density,
items.wtpermtr,
items.areapermtr,
items.sectiondim1, items.sectiondim2, items.sectiondim3,

itemsubcats.initialcode,itemsubcats.subcatname,
itemscheds.itemschedid,itemscheds.schedname,
itemsubcats.xname,itemsubcats.yname,itemsubcats.zname,itemsubcats.sname,itemsubcats.pname

from items
	inner join itemsubcats on items.subcatid = itemsubcats.subcatid
	inner join itemunits on itemsubcats.itemunitid = itemunits.itemunitid
	inner join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
	left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid











)









GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncGetHWType]'
GO




CREATE     FUNCTION [dbo].[fncGetHWType](@HWTypeXML varchar(max),@elementcode int)
RETURNS varchar(1000)
AS  
BEGIN 
	declare @doc xml
	declare @element varchar(1000)

	set @doc = convert(xml,'<ROOT>'+@hwtypexml+'</ROOT>')

	if isnull(@hwtypexml,'')<>'' begin
		select top 1 @element=myxml.val.value('./@TEXT','varchar(1000)')
		from @doc.nodes('/ROOT/VALUE') myxml(val) where myxml.val.value('./@VALUE1','int')=@elementcode
	end

	return @element
END



GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItemCalc]'
GO
CREATE TABLE [dbo].[DrgItemCalc]
(
[DrgItemCalcID] [int] NOT NULL IDENTITY(1, 1),
[DrgItemID] [int] NULL,
[ChildDrgItemID] [int] NULL,
[ItemID] [int] NULL,
[Qty] [decimal] (18, 2) NULL,
[Legend] [varchar] (50) NULL,
[Reference] [varchar] (1000) NULL,
[RefIDList] [varchar] (1000) NULL,
[Thk] [decimal] (18, 4) NULL,
[Length] [decimal] (18, 4) NULL,
[Width] [decimal] (18, 4) NULL,
[InnerDia] [decimal] (18, 4) NULL,
[OuterDia] [decimal] (18, 4) NULL,
[Length2] [decimal] (18, 4) NULL,
[Width2] [decimal] (18, 4) NULL,
[Thread] [decimal] (18, 4) NULL,
[AreaReduce] [decimal] (18, 4) NULL,
[Weight] [decimal] (18, 4) NULL,
[Description] [varchar] (1000) NULL,
[DescripChart] [varchar] (1000) NULL,
[Specification] [varchar] (1000) NULL,
[CNCDrgNew] [varchar] (1000) NULL,
[CNCDrgNew2] [varchar] (8000) NULL,
[CNCDrgNew3] [varchar] (8000) NULL,
[CNCDrgNew4] [varchar] (8000) NULL,
[CNCTypeIDNew] [int] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DrgItemC__2F6BB98E3B40CD36] on [dbo].[DrgItemCalc]'
GO
ALTER TABLE [dbo].[DrgItemCalc] ADD CONSTRAINT [PK__DrgItemC__2F6BB98E3B40CD36] PRIMARY KEY CLUSTERED  ([DrgItemCalcID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDUnit]'
GO
CREATE TABLE [dbo].[PIDUnit]
(
[PIDUnitID] [int] NOT NULL IDENTITY(1, 1),
[Customer] [varchar] (1000) NULL,
[Descrip] [varchar] (50) NULL,
[FileNum] [varchar] (900) NULL,
[FileVol] [int] NULL,
[FileNumComp] AS ([FileNum]+case when isnull([filevol],(0))>(0) then ' - Vol. '+CONVERT([varchar],[filevol],(0)) else '' end),
[IsCompleted] [bit] NULL,
[OrderDate] [datetime] NULL,
[DesignDate] [datetime] NULL,
[Remarks] [varchar] (1000) NULL,
[StartupDefID] [int] NULL,
[Lastupdated] [datetime] NULL,
[TemplateFileName] [varchar] (8000) NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__PIDUnit__A58000ED15502E78] on [dbo].[PIDUnit]'
GO
ALTER TABLE [dbo].[PIDUnit] ADD CONSTRAINT [PK__PIDUnit__A58000ED15502E78] PRIMARY KEY CLUSTERED  ([PIDUnitID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListPIDUnit]'
GO





CREATE             function [dbo].[desListPIDUnit]()
returns table
	return (


select 

pidunit.pidunitid, FileNum, FileVol,IsCompleted, orderdate as dated, lastupdated,
startupdefid,pidunit.templatefilename,descrip + '-' + customer as pidinfo,pidunit.descrip as woinfo,
      Customer, Descrip, FileNumComp,    
      OrderDate,DesignDate,
      Remarks


from pidunit



)


























































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[invListItemSubCats]'
GO








CREATE                      function [dbo].[invListItemSubCats]()
returns table
return (


select ItemUnits.NameSingular,
itemunits.itemunitid,itemunits.nameplural as unitname,
itemsubcats.strmaint,itemscheds.schedcode,
ItemUnits.NamePlural,ItemSubcats.subcatid,itemsubcats.invcatid,

cnctypes.isgasket, cnctypes.initemcollec, cnctypes.cnctypeid, cnctypes.cnctypename,

itemsubcats.vendorlisthead,itemsubcats.purchasespec,

itemsubcats.hasdefs,itemsubcats.hasdefscost,itemsubcats.keeptrack,
itemsubcats.bomsectiontypecode,itemsubcats.intankdrawings, itemsubcats.drgbomname, itemsubcats.density,

itemsubcats.dim1param, itemsubcats.dim2param, itemsubcats.dim3param,
isnull(itemsubcats.costingtype,0) as costingtype,itemsubcats.costingitemid,
itemsubcats.paramxmlx, itemsubcats.paramxmly, itemsubcats.paramxmlz, itemsubcats.paramxmlp, itemsubcats.paramxmls, 

case when isnull(iswospecific,0)=1 then 'WO Specific' + case when isnull(ismacmaint,0)=1 then ' / ' else '' end 
else '' end
+ case when isnull(ismacmaint,0)=1 then 'Machinery Maintenance' + case when isnull(isstock,0)=1 then ' / ' else '' end else '' end
+ case when isnull(iswospecific,0)=1 and isnull(ismacmaint,0)=0 and isnull(isstock,0)=1 then ' / ' else '' end
+ case when isnull(isstock,0)=1 then 'Stock' else '' end as SubCatType,

itemsubcats.initialcode,itemsubcats.subcatname,itemscheds.itemschedid,itemscheds.schedname,
itemsubcats.xname,itemsubcats.yname,itemsubcats.zname,itemsubcats.sname,itemsubcats.pname,
itemsubcats.xnamecost,itemsubcats.ynamecost,itemsubcats.znamecost,itemsubcats.snamecost,itemsubcats.pnamecost

from itemsubcats
	inner join itemunits on itemsubcats.itemunitid = itemunits.itemunitid
	inner join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
	left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid










)









































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListStdDrg]'
GO





CREATE        function [dbo].[desListStdDrg]()
returns table
	return (


select StdDrgID,
case when revduefrom is null then 1 else 0 end as iscompleted,
StdSeries,DrgNum,GroupNum,

CompleteNum, DrgName, 

Descrip,
RevNum,RevDate,
RevDue, RevDueFrom,   ForFile


from stddrg
	
)















































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNestReq]'
GO
CREATE TABLE [dbo].[TFNestReq]
(
[TFNestReqID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[DesDocGrp] [varchar] (1000) NULL,
[DrgItemID] [int] NULL,
[ReqDate] [datetime] NULL,
[WorkGroup] [varchar] (1000) NULL,
[Remark] [varchar] (1000) NULL,
[IsCompleted] [bit] NULL,
[Qty] [int] NULL,
[CNCTypeID] [int] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__TFNestRe__1D52F0BA300424B4] on [dbo].[TFNestReq]'
GO
ALTER TABLE [dbo].[TFNestReq] ADD CONSTRAINT [PK__TFNestRe__1D52F0BA300424B4] PRIMARY KEY CLUSTERED  ([TFNestReqID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNestItems]'
GO
CREATE TABLE [dbo].[TFNestItems]
(
[TFNestItemID] [int] NOT NULL IDENTITY(1, 1),
[TFNestReqID] [int] NULL,
[SNum] [decimal] (18, 4) NULL,
[CNCDrg] [varchar] (1000) NULL,
[PartNum] [varchar] (100) NULL,
[Reference] [varchar] (8000) NULL,
[Description] [varchar] (1000) NULL,
[Specification] [varchar] (8000) NULL,
[QtyReq] [int] NULL,
[Qty] [int] NULL,
[TFNestID] [int] NULL,
[NoCommonCut] [bit] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__TFNestIt__72A9E56537A5467C] on [dbo].[TFNestItems]'
GO
ALTER TABLE [dbo].[TFNestItems] ADD CONSTRAINT [PK__TFNestIt__72A9E56537A5467C] PRIMARY KEY CLUSTERED  ([TFNestItemID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNest]'
GO
CREATE TABLE [dbo].[TFNest]
(
[TFNestID] [int] NOT NULL IDENTITY(1, 1),
[Thk] [decimal] (18, 2) NULL,
[NestNum] [int] NULL,
[NestNumFab] [int] NULL,
[RevNum] [int] NULL,
[RevDate] [datetime] NULL,
[Remark] [varchar] (1000) NULL,
[CutterDia] [decimal] (18, 2) NULL,
[SUmmary] [varchar] (1000) NULL,
[SheetWidth] [decimal] (18, 2) NULL,
[SheetLength] [decimal] (18, 2) NULL,
[SheetQty] [int] NULL,
[IsNested] [bit] NULL,
[SheetBOMXML] [text] NULL,
[CNCTypeID] [int] NULL,
[Dated] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__TFNest__DB75889633D4B598] on [dbo].[TFNest]'
GO
ALTER TABLE [dbo].[TFNest] ADD CONSTRAINT [PK__TFNest__DB75889633D4B598] PRIMARY KEY CLUSTERED  ([TFNestID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItemParam]'
GO
CREATE TABLE [dbo].[DrgItemParam]
(
[DrgItemParamID] [int] NOT NULL IDENTITY(1, 1),
[DrgItemID] [int] NULL,
[StdDrgParamID] [int] NULL,
[IsUser] [bit] NULL,
[ParamValue] [decimal] (18, 4) NULL,
[StdDrgParamID2] [int] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DrgItemP__92E8F5D12C3393D0] on [dbo].[DrgItemParam]'
GO
ALTER TABLE [dbo].[DrgItemParam] ADD CONSTRAINT [PK__DrgItemP__92E8F5D12C3393D0] PRIMARY KEY CLUSTERED  ([DrgItemParamID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemCodeDef]'
GO
CREATE TABLE [dbo].[ItemCodeDef]
(
[ItemCodeDefID] [int] NOT NULL IDENTITY(1, 1),
[SubCATID] [int] NULL,
[GrpNum] [int] NULL,
[CodeValue] [varchar] (7) NULL,
[CodeText] [varchar] (1000) NULL,
[Remark] [varchar] (1000) NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__ItemCode__1E0179F217036CC0] on [dbo].[ItemCodeDef]'
GO
ALTER TABLE [dbo].[ItemCodeDef] ADD CONSTRAINT [PK__ItemCode__1E0179F217036CC0] PRIMARY KEY CLUSTERED  ([ItemCodeDefID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemSubCatDef]'
GO
CREATE TABLE [dbo].[ItemSubCatDef]
(
[ItemSubCatDefID] [int] NOT NULL IDENTITY(1, 1),
[SubCatID] [int] NULL,
[GrpNum] [int] NULL,
[CharNum] [int] NULL,
[Name] [varchar] (1000) NULL,
[DesParamID] [int] NULL,
[MultFactor] [decimal] (18, 4) NULL,
[FixedValue] [varchar] (1000) NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemSubCatDef] on [dbo].[ItemSubCatDef]'
GO
ALTER TABLE [dbo].[ItemSubCatDef] ADD CONSTRAINT [PK_ItemSubCatDef] PRIMARY KEY CLUSTERED  ([ItemSubCatDefID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[StdDrgParam]'
GO
CREATE TABLE [dbo].[StdDrgParam]
(
[StdDrgParamID] [int] NOT NULL IDENTITY(1, 1),
[StdDrgID] [int] NULL,
[ParamName] [varchar] (50) NULL,
[Formula] [varchar] (8000) NULL,
[Descrip] [varchar] (1000) NULL,
[MinValue] [decimal] (18, 4) NULL,
[MaxValue] [decimal] (18, 4) NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__StdDrgPa__4DBC1F33117F9D94] on [dbo].[StdDrgParam]'
GO
ALTER TABLE [dbo].[StdDrgParam] ADD CONSTRAINT [PK__StdDrgPa__4DBC1F33117F9D94] PRIMARY KEY CLUSTERED  ([StdDrgParamID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNestSheet]'
GO
CREATE TABLE [dbo].[TFNestSheet]
(
[TFNestSheetID] [int] NOT NULL IDENTITY(1, 1),
[TFNestID] [int] NULL,
[LayoutNum] [int] NULL,
[Width] [int] NULL,
[Length] [int] NULL,
[perUtil] [decimal] (18, 2) NULL,
[cncdrg] [varchar] (1000) NULL,
[ncfile] [varchar] (1000) NULL,
[PartXML] [varchar] (max) NULL,
[cncdrgrem] [varchar] (1000) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFNestSheet] on [dbo].[TFNestSheet]'
GO
ALTER TABLE [dbo].[TFNestSheet] ADD CONSTRAINT [PK_TFNestSheet] PRIMARY KEY CLUSTERED  ([TFNestSheetID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListProDocu]'
GO



CREATE              function [dbo].[desListProDocu]()
returns table
	return (


select 

prodocuid, prodocu.pidunitid, serialnum,
prodocu.revnum,prodocu.revdate,prodocu.hasBOM,prodocu.hascollec,
prodocu.refdrg,  prodocu.docname, prodocu.suffix, prodocu.prefix, prodocu.bommaxnum,
prodocu.docempid, prodocu.reportstatus,prodocu.reportremark, prodocu.desdocgrp,

prodocu.issuedon, prodocu.planon,isnull(prodocu.blanklinea,0) as blanklinea,isnull(prodocu.blanklineb,0) as blanklineb,

dlpu.filenumcomp,dlpu.filenum,prodocu.drgnum,
dlpu.pidinfo, dlpu.woinfo,

case when issuedon is null then 0 else 1 end as iscompleted,

case when prodocu.issuedon is null then 'Plan' + 
	case when prodocu.planon is null then '' else ' ' + convert(varchar,prodocu.planon,106) end
else convert(varchar,prodocu.issuedon,106) end as issuedonsct,

prodocu.drgon, prodocu.chkon, prodocu.appon,
prodocu.remark,prodocu.prepbyid, prodocu.prepbyid2, prodocu.chkbyid, prodocu.appbyid,
prodocu.drgnum as Drawing,

dlpu.descrip,dlpu.customer,

case when isnull(revNUM,'')<>'' then ' Rev ' + convert(varchar,isnull(revnum,0)) else '' end + case when revdate is not null then ' Dt. ' + convert(varchar,revdate,106) else '' end  as Revision,

upper(isnull(Prefix,'') + ' ' + isnull(DocName,'') + ' ' + isnull(Suffix,'')) as Document,


NumSheets, 
NumCopies,

case when issuedon is not null then convert(varchar,issuedon,106) + ' ' 
when appon is not null then 'Compl. on ' + convert(varchar,appon,106) + ' '
else '' end  

+ isnull(prodocu.remark,'')
as Remarks


from ProDocu 
	inner join deslistpidunit() as dlpu on prodocu.pidunitid = dlpu.pidunitid

)
































































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDrgItemCalc]'
GO






















CREATE function [dbo].[desListDrgItemCalc]()
returns table
	return (


select DrgItems.DrgItemid, DrgItems.ProDocuID, dlpd.pidunitid, 
drgitems.refdrgitemid,cnctypes.inattachmatlist,
drgitemcalc.ChildDrgItemID,drgitemcalc.drgitemcalcID,stddrg.stddrgid,dlpd.desdocgrp,
isnull(ili.bomsectiontypecode,0) as bomsectiontypecode, 
ili.initialcode,
dr2.specification as specparent, dr2.description as descripparent,
isnull(Drgitems.haslegend,0) as haslegend, 
drgitemcalc.legend, drgitemcalc.refidlist,
case when drgitems.drgitemid = dr2.drgitemid then 'PART' + convert(varchar,drgitems.drgitemid)
else 'PARTBOM' + convert(varchar,dr2.drgitemid) end as DrgItemPartID,

 case when drgitemcalc.width2=0 then '-' else 
	case when drgitemcalc.[length]-drgitemcalc.length2 = drgitemcalc.width-drgitemcalc.width2 then 	convert(varchar,convert(Decimal(18,1),(drgitemcalc.Width-drgitemcalc.Width2)/2),0) else convert(varchar,convert(Decimal(18,1),(drgitemcalc.[length]-drgitemcalc.length2)/2),0) + ',' + convert(varchar,convert(decimal(18,1),(drgitemcalc.Width-drgitemcalc.Width2)/2),0) end
end as Wid,

cnctypes.cnctypename,cnctypes.cnctypeid, ili.ishardware, cnctypes.titleqc,

dlpd.pidinfo + '           BILL OF MATERIAL' + char(10) + char(13)+
dlpd.drawing + '          -' + dlpd.[document] as bominfo,

dr2.stddrgid as refstddrgid,
ili.schedname,ili.itemschedid,
dr2.prodocuid as refprodocuid,

dbo.fncstringnum(drgitems.itemnum,dlpd.bommaxnum) as ItemNum,

drgitems.iscollection,

dlpd2.pidunitid as refpidunitid,

isnull(drgitems.descripchartaddl,'') + case when isnull(drgitems.descripchartaddl,'')='' then '' else ' ' end +
drgitemcalc.descripchart as DescripChart,
dr2.nocommoncut,dr2.gaskettypecode,dr2.iswelded,

isnull(ili.isgasket,0) as isgasket,isnull(dr2.itemcollectypecode,0) as itemcollectypecode,

case when isnull(dr2.itemcollectypecode,0)=1 then
dbo.fncGetHWType(ili.pxmlc,ili.pvaluec) else '' end as element, ili.pvaluec,

drgitemcalc.qty/drgitems.qty as bomqty,

convert(varchar,drgitems.drgitemid) + ':' + isnull(convert(varchar,dr2.drgitemid),'') as hwctcode,

dlpd.woinfo, ili.subcatid, ili.itemid, dlpd.hascollec, 
ili.perwastage, ili.itemname, ili.subcatname,  ili.itemcode,


dr2.drgitemid as partdrgitemid,		--for hardware crosstab (no select distinct)

dr2.matsection,drgitemcalc.length,drgitemcalc.length2,drgitemcalc.width,drgitemcalc.width2,drgitemcalc.innerdia,
drgitemcalc.outerdia,dr2.hasnojoints,

isnull(dr2.isboughtout,0) as IsBoughtOut,
drgitemcalc.cncdrgnew,drgitemcalc.cncdrgnew2,drgitemcalc.cncdrgnew3,drgitemcalc.cncdrgnew4,
case when len(drgitemcalc.cncdrgnew2)>0 then drgitemcalc.cncdrgnew2 else dr2.cncdrg2 end as cncdrg2,
case when len(drgitemcalc.cncdrgnew3)>0 then drgitemcalc.cncdrgnew3 else dr2.cncdrg3 end as cncdrg3,
case when len(drgitemcalc.cncdrgnew4)>0 then drgitemcalc.cncdrgnew4 else dr2.cncdrg4 end as cncdrg4,

dr2.Category,dr2.SubCategory,

case when len(isnull(drgitemcalc.cncdrgnew,dr2.CNCDrg))=0
then 'Not OK' else 'OK' end as CNCStatus,

case when len(drgitemcalc.cncdrgnew)>0 then drgitemcalc.cncdrgnew else dr2.cncdrg end as CNCDrg,



--case when drgitembom.itemid is null then
		case when dlpd2.prodocuid is null then case when isnull(sd2.isghost,0)=0 then isnull(sd2.completenum,'') end
		else isnull(dlpd2.drawing,'') end
			+ ' - ' + isnull(dr2.itemnum,'') +
	case when isnull(dr2.isboughtout,0)=1 then ' (Bought out)' else '' end
--else ili.itemcode end
as PartNum,


case when isnull(Dr2.drgitemid,0)=isnull(drgitems.drgitemid,0) then '' else 
drgitemcalc.reference end as Reference,

drgitemcalc.Description,

drgitemcalc.Thk,

drgitemcalc.Specification,

case when len(dr2.Material)=0 then 
			case when len(ili.drgbomname)=0 then ili.subcatname else ili.drgbomname end 
else dr2.Material end as Material,

drgitemcalc.Qty,

case when isnull(Dr2.seedetail,0)  =1 
then 'SEE DETAIL' else '' end +dr2.Remark as Remark,

drgitemcalc.Weight

from DrgItemCalc
inner join drgitems on drgitemcalc.drgitemid = drgitems.drgitemid
inner join deslistprodocu() as dlpd on drgitems.prodocuid = dlpd.prodocuid
inner join drgitems as dr2 on drgitemcalc.childdrgitemid = dr2.drgitemid
left join deslistprodocu() as dlpd2 on dr2.prodocuid = dlpd2.prodocuid
left join stddrg on drgitems.stddrgid = stddrg.stddrgid
left join stddrg as sd2 on dr2.stddrgid = sd2.stddrgid
left join invlistitems() as ili on drgitemcalc.itemid= ili.itemid
left join cnctypes on isnull(drgitemcalc.cnctypeidnew,ili.cnctypeid)= cnctypes.cnctypeid

--TODO: provision for standard assembly parts

)









































































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[camListReqItems]'
GO










CREATE function [dbo].[camListReqItems]()
returns table
	return (


select tfnestreq.tfnestreqid, tfnestreq.pidunitid, tfnestreq.iscompleted,

dldip.DrgItemid, ProDocuID, ChildDrgItemID, drgitemcalcID, stddrgid, 
tfnestreq.reqdate,
dldip.desdocgrp,dldip.nocommoncut,

DrgItemPartID,IsBoughtOut,CNCStatus,
CNCDrg,cncdrg2,cncdrg3,cncdrg4,
tlts.woinfo as reqinfo,

Category,
SubCategory,

PartNum,

Reference,

Description,
Specification,
Thk,

--convert(int,(select sum(qty) from tfnestitems where tfnestreq.tfnestreqid = tfnestitems.tfnestreqid and dldip.drgitempartid = tfnestitems.drgitempartid)) as qtydone,

convert(int,case when isnull(tfnestreq.qty,0)>0 then tfnestreq.qty else 1 end*dldip.Qty) as Qty,

dldip.Remark,
Weight

from tfnestreq
inner join deslistpidunit() as tlts on tfnestreq.pidunitid = tlts.pidunitid
inner join deslistDrgItemcalc() as dldip on dldip.pidunitid = tlts.pidunitid and dldip.desdocgrp = tfnestreq.desdocgrp and dldip.cnctypeid = tfnestreq.cnctypeid




)



































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDrgItems]'
GO



CREATE function [dbo].[desListDrgItems]()
returns table
	return (


select DrgItems.DrgItemid, 
itemscheds.schedname,
stddrg.StdDrgID,  dlpd.ProDocuID,drgitems.itemnum1,drgitems.itemnum2,
dr2.stddrgid as refstddrgid, dr2.prodocuid as refprodocuid,pd2.pidunitid as refpidunitid,
case when isnull(drgitems.qty,0)=0 then 1 else drgitems.qty end as wtqty,

drgitems.haslegend,
drgitems.itemid, drgitems.itemcollectypecode,drgitems.iswelded,
items.subcatid, itemsubcats.bomsectiontypecode, items.bomthk, 
cnctypes.cnctypeid, cnctypes.cnctypename, cnctypes.isgasket,
dlpd.descrip + '           BILL OF MATERIAL' + char(10) + char(13)+
dlpd.drgnum + '          -' + dlpd.[document] as bominfo,dlpd.drawing,

isnull(case when stddrg.stddrgid is null then dlpd.hascollec else stddrg.hascollec end,0) as hascollec,
case when stddrg.stddrgid is null then 0 else 1 end as isstd, stddrg.groupnum,

case when dlpd.prodocuid is null then 0 else
case when isnull(dlpd.hascollec,0)=0 or isnull(drgitems.iscollection,0)=1 then 1 else 0 end end as hascalc,

dlpd.pidunitid,dlpd.hasbom, dlpd.bommaxnum, dlpd.drgnum,
DrgItems.MatSection,DrgItems.CNCDrg,DrgItems.Category,DrgItems.SubCategory,

drgitems.InnerDia, drgitems.Length2, drgitems.Length, drgitems.OuterDia, 
drgitems.Width2, drgitems.Width, drgitems.descripchart,drgitems.descripchartaddl,

drgitems.rectreducexml, drgitems.roundreducexml, drgitems.trianglereducexml, drgitems.radiusreducexml,

drgitems.paramreqxml, drgitems.paramvaluexml, itemsubcats.density, Items.WtPerMtr,
drgitems.InnerDiaParamID, drgitems.Length2ParamID, drgitems.LengthParamID, drgitems.OuterDiaParamID, 
drgitems.Width2ParamID, drgitems.WidthParamID, drgitems.ThkParamID, drgitems.ThreadParamId,

DrgItems.RefDrgItemID,

isnull(DrgItems.IsCollection,0) as iscollection,
stddrg.completenum + ' - ' + stddrg.DrgName as stddrg, drgitems.isdeleted,

isnull(dlpd.drgnum,stddrg.completenum) as Doc,
isnull(dlpd.filenum,' STD') as FileNum,

dbo.fncstringnum(drgitems.itemnum,isnull(dlpd.bommaxnum,stddrg.bommaxnum)) as ItemNum,

		
DrgItems.Thk,
case when isnull(DrgItems.isdeleted,0)=1 then '*Deleted*' else '' end+
case when dlpd.prodocuid is not null then dlpd.drgnum + ' - ' + DrgItems.itemnum
else stddrg.completenum + ' - ' + DrgItems.itemnum end as Item,

DrgItems.Description, 

replace(DrgItems.Specification,'- 901','') as Specification, 

case when isnull(drgitems.material,'')='' then
	case when isnull(itemsubcats.drgbomname,'')='' then itemsubcats.subcatname else itemsubcats.drgbomname end
else drgItems.Material
end as Material, 


DrgItems.Qty, 

case when isnull(drgitems.seedetail,0)=1 then 'SEE DETAIL' else '' end +
isnull(drgItems.Remark,'') as Remark, 

DrgItems.Weight


from DrgItems
left join deslistprodocu() as dlpd on drgitems.prodocuid = dlpd.prodocuid
left join stddrg on drgItems.stddrgid = stddrg.stddrgid
left join drgitems as dr2 on drgitems.refdrgitemid = dr2.drgitemid
left join prodocu as pd2 on dr2.prodocuid = pd2.prodocuid
left join items on drgitems.itemid = items.itemid
left join itemsubcats on items.subcatid = itemsubcats.subcatid
left join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid

)

















































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDrgItemBOM]'
GO
















CREATE function [dbo].[desListDrgItemBOM]()
returns table
	return (


select drgitembom.ChildDrgItemID, drgItemBOMID,drgitemBOM.DrgItemid, 
drp.ProDocuID, drp.stddrgid, drc.stddrgid as refstddrgid,drc.prodocuid as refprodocuid,
drc.MatSection,drc.Thk,Drc.Length,Drc.Width,dlpd.pidunitid,

case when isnull(drc.qty,0)=0 then 1 else drc.qty end as wtqty,
case when dlpd.hascollec=1 then drp.itemnum else 'Qty' end as listpivot,
case when dlpd.hascollec=1 then 'Qty'+ case when isnull(drp.itemnum,'')='901' then '' else char(10) + char(13)+drp.itemnum end else 'Qty'  end as listpivotcaption,
case when drc.drgitemid is null then 'PART' + convert(varchar,drp.drgitemid)
else 'PARTBOM' + convert(varchar,drc.drgitemid) end as DrgItemPartID,
drc.drgitemid as partdrgitemid,		--for hardware crosstab (no select distinct)
dbo.fncstringnum(drc.itemnum,isnull(dlpd.bommaxnum,0)) as bomitemnum,
dlpd.pidinfo + '           BILL OF MATERIAL' + char(10) + char(13)+
dlpd.drawing + '          -' + dlpd.[document] as bominfo,

drgitembom.cncdrg,items.itemcode, drgitembom.legend, drc.haslegend,
items.itemid, itemsubcats.subcatid, items.wtperno, items.itemname, items.bommatsection,
itemsubcats.pvaluea, itemsubcats.pvalueb, itemsubcats.pvaluec, itemsubcats.pvalued, 
itemsubcats.pvaluee, items.xvalue, items.yvalue, items.zvalue, items.svalue, items.pvalue,
drc.paramreqxml, drc.paramvaluexml,

drgitembom.specbom,drgitembom.descripbom,

case when isnull(drc.qty,0)>0 then isnull(drc.weight,0)/drc.qty else drc.weight end as wtpu,
Drc.Category,Drc.SubCategory,Drc.RefDrgItemID,Drp.IsCollection,

Drc.ItemNum, 
case when isnull(drc.isdeleted,0)=1 then '*Deleted*' else '' end+
Drc.Description as Description, 

Drc.Specification, 
Drc.Material, DrgItemBOM.Qty, 

DrgItemBom.QtyParamID,

Drc.Remark, case when drc.drgitemid is null then drgitembom.weight else drc.weight end as weight


from DrgItemBOM
	inner join drgitems as drp on drgitembom.drgitemid = drp.drgitemid
	left join deslistDrgItems() as drc on drgitemBOM.childdrgitemid=drc.drgitemid
	left join deslistprodocu() as dlpd on drp.prodocuid = dlpd.prodocuid
	left join items on drgitembom.itemid = items.itemid
	left join itemsubcats on items.subcatid = itemsubcats.subcatid

)




























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[camListReq]'
GO




CREATE function [dbo].[camListReq]()
returns table
	return (


select tfnestreq.tfnestreqid, 
tfnestreq.drgitemid,tlts.pidunitid, tfnestreq.cnctypeid,
tfnestreq.iscompleted, 

Customer,'' as Rating,
woinfo as ReqInfo, WOInfo,
tfnestreq.DesDocGrp, 

deslistdrgitems.Item, tfnestreq.Qty, 

tfnestreq.ReqDate,

tfnestreq.WorkGroup,

case when isnull(tfnestreq.IsCompleted,0)=0 then 'Incomplete' else 'Complete' end as Status,

tfnestreq.Remark

from tfnestreq
inner join deslistpidunit() as tlts on tfnestreq.pidunitid = tlts.pidunitid
left join deslistdrgitems() on tfnestreq.drgitemid = deslistdrgitems.drgitemid

)































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[camListNestItems]'
GO








CREATE function [dbo].[camListNestItems]()
returns table
	return (


select tfnestitems.tfnestitemid, tfnestitems.tfnestreqid, tfnestitems.tfnestid,
 camlistreq.iscompleted,
tfnestitems.snum,
tfnest.thk, camlistreq.reqdate,
camlistreq.DrgItemid, camlistreq.pidunitid, 

camlistreq.desdocgrp,
tfnestitems.nocommoncut,
tfnestitems.CNCDrg,
camlistreq.reqinfo,
tfnestitems.PartNum,
tfnestitems.Reference,
tfnestitems.Description,
--flri.qty - (select sum(qty) from tfnestitems as tfni2 where tfni2.tfnestreqid = tfnestitems.tfnestreqid and tfni2.drgitempartid = tfnestitems.drgitempartid) as Bal,
tfnestitems.Specification,
tfnestitems.QtyReq,
tfnestitems.Qty

from tfnestitems
inner join tfnest on tfnestitems.tfnestid = tfnest.tfnestid
inner join camlistreq() on tfnestitems.tfnestreqid = camlistreq.tfnestreqid
--inner join camlistreqitems() as flri on tfnestitems.tfnestreqid = flri.tfnestreqid and tfnestitems.drgitempartid=flri.drgitempartid


)





































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncMax]'
GO












CREATE  function [dbo].[fncMax](@val1 decimal(18,4),@val2 decimal(18,4))
returns decimal(18,4)
begin
	declare @val decimal(18,4)
	set @val=case when @val1>@val2 then @val1 else @val2 end
	return @val
end


















GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DBVersion]'
GO
CREATE TABLE [dbo].[DBVersion]
(
[DBVersionID] [int] NOT NULL IDENTITY(1, 1),
[Version] [decimal] (18, 4) NULL,
[MinClientVersion] [varchar] (50) NULL,
[UpdatedOn] [datetime] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DBVersio__8ACF624E1CF15040] on [dbo].[DBVersion]'
GO
ALTER TABLE [dbo].[DBVersion] ADD CONSTRAINT [PK__DBVersio__8ACF624E1CF15040] PRIMARY KEY CLUSTERED  ([DBVersionID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[sysRowLocks]'
GO
CREATE TABLE [dbo].[sysRowLocks]
(
[sysRowLockID] [int] NOT NULL IDENTITY(1, 1),
[IDField] [nvarchar] (50) NULL,
[IDValue] [int] NULL,
[CreatedOn] [datetime] NULL,
[CreatedBy] [nvarchar] (50) NULL,
[LastModifiedOn] [datetime] NULL,
[LastModifiedBy] [nvarchar] (50) NULL,
[OpenedBy] [nvarchar] (50) NULL,
[OpenedFromPC] [nvarchar] (50) NULL,
[OpenedFromApp] [nvarchar] (50) NULL,
[OpenedOn] [datetime] NULL,
[ClosedOn] [datetime] NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__sysRowLo__D858C6031920BF5C] on [dbo].[sysRowLocks]'
GO
ALTER TABLE [dbo].[sysRowLocks] ADD CONSTRAINT [PK__sysRowLo__D858C6031920BF5C] PRIMARY KEY CLUSTERED  ([sysRowLockID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[SystemOptions]'
GO
CREATE TABLE [dbo].[SystemOptions]
(
[SystemOptionID] [int] NOT NULL IDENTITY(1, 1),
[CompanyName] [nvarchar] (1000) NULL,
[CompanyAddress] [nvarchar] (4000) NULL
) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__SystemOp__2AA044A9534D60F1] on [dbo].[SystemOptions]'
GO
ALTER TABLE [dbo].[SystemOptions] ADD CONSTRAINT [PK__SystemOp__2AA044A9534D60F1] PRIMARY KEY CLUSTERED  ([SystemOptionID]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[sp_GetTablePerms]'
GO







CREATE     PROCEDURE [dbo].[sp_GetTablePerms] @txtTblName varchar(50) AS

DECLARE @intPerms       INT

/* Make sure table name passed as parameter */
IF @txtTblName Is Null BEGIN
   SELECT -1 AS Permission,@txttblname as obj
   RETURN (-1)
END

/* Check for invalid table name */
IF (SELECT OBJECT_ID(@txtTblName)) IS NULL BEGIN
   SELECT -1 AS Permission,@txttblname as obj
   RETURN (-1)
END

/* Calculate permissions and return to calling program */
SELECT @intPerms = PERMISSIONS(OBJECT_ID(@txtTblName))
SELECT @intPerms As Permission,@txttblname as Obj

RETURN (@intPerms)








GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemSubCats]'
GO
ALTER TABLE [dbo].[ItemSubCats] ADD
CONSTRAINT [FK_ItemSubCats_CNCTypes] FOREIGN KEY ([CNCTypeID]) REFERENCES [dbo].[CNCTypes] ([CNCTypeID]) ON DELETE SET NULL ON UPDATE CASCADE,
CONSTRAINT [FK_ItemSubCats_ItemScheds] FOREIGN KEY ([ItemSchedID]) REFERENCES [dbo].[ItemScheds] ([ItemSchedID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_ItemSubCats_ItemUnits] FOREIGN KEY ([ItemUnitID]) REFERENCES [dbo].[ItemUnits] ([ItemUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItemBOM]'
GO
ALTER TABLE [dbo].[DrgItemBOM] ADD
CONSTRAINT [FK_DrgItemBOM_DrgItems] FOREIGN KEY ([DrgItemID]) REFERENCES [dbo].[DrgItems] ([DrgItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItemCalc]'
GO
ALTER TABLE [dbo].[DrgItemCalc] ADD
CONSTRAINT [FK_DrgItemCalc_DrgItems] FOREIGN KEY ([DrgItemID]) REFERENCES [dbo].[DrgItems] ([DrgItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItemParam]'
GO
ALTER TABLE [dbo].[DrgItemParam] ADD
CONSTRAINT [FK_DrgItemParam_DrgItems] FOREIGN KEY ([DrgItemID]) REFERENCES [dbo].[DrgItems] ([DrgItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItems]'
GO
ALTER TABLE [dbo].[DrgItems] ADD
CONSTRAINT [FK_DrgItems_StdDrg] FOREIGN KEY ([StdDrgID]) REFERENCES [dbo].[StdDrg] ([StdDrgID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_DrgItems_ProDocu] FOREIGN KEY ([ProDocuID]) REFERENCES [dbo].[ProDocu] ([ProDocuID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemCodeDef]'
GO
ALTER TABLE [dbo].[ItemCodeDef] ADD
CONSTRAINT [FK_ItemCodeDef_ItemSubCats] FOREIGN KEY ([SubCATID]) REFERENCES [dbo].[ItemSubCats] ([SubCatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[Items]'
GO
ALTER TABLE [dbo].[Items] ADD
CONSTRAINT [FK_Items_ItemSubCats] FOREIGN KEY ([SubCatID]) REFERENCES [dbo].[ItemSubCats] ([SubCatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemSubCatDef]'
GO
ALTER TABLE [dbo].[ItemSubCatDef] ADD
CONSTRAINT [FK_ItemSubCatDef_ItemSubCats] FOREIGN KEY ([SubCatID]) REFERENCES [dbo].[ItemSubCats] ([SubCatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ProDocu]'
GO
ALTER TABLE [dbo].[ProDocu] ADD
CONSTRAINT [FK_ProDocu_PIDUnit] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[StdDrgParam]'
GO
ALTER TABLE [dbo].[StdDrgParam] ADD
CONSTRAINT [FK_StdDrgParam_StdDrg] FOREIGN KEY ([StdDrgID]) REFERENCES [dbo].[StdDrg] ([StdDrgID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFNestSheet]'
GO
ALTER TABLE [dbo].[TFNestSheet] ADD
CONSTRAINT [FK_TFNestSheet_TFNest] FOREIGN KEY ([TFNestID]) REFERENCES [dbo].[TFNest] ([TFNestID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
